EXERCISE 4 - PROJECT TASK MANAGEMENT

Separate files:
- backend/server.js: Express + MongoDB API
- backend/package.json: backend dependencies
- frontend/src/App.js: React UI
- frontend/src/App.css: styling
- frontend/package.json: frontend dependencies
- .gitignore

Run requirements:
1. Install Node.js and start MongoDB locally.
2. Backend: open terminal in backend, run `npm install`, then `npm start`.
3. Frontend: open terminal in frontend, run `npm install`, then `npm start`.

The package.json files are included to make dependency installation easier; the source code is based on Exercise 4 in the supplied manual, with spacing/JSX formatting cleaned up after text extraction.
